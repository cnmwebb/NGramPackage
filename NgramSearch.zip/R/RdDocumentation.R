setwed("./ngramSearchPackage")
document()
